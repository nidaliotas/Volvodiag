package lt.volvodiag

/** Standartinės OBD-II (SAE J1979) užklausos ir atsakymų dekodavimas. */
object Obd {

    data class Pid(
        val code: Int,
        val name: String,
        val unit: String,
        val decimals: Int,
        val calc: (IntArray) -> Double
    )

    /** Gyvi duomenys, kuriuos rodom (jei automobilis juos palaiko). */
    val LIVE_PIDS = listOf(
        Pid(0x0C, "Apsukos", "rpm", 0) { d -> (d[0] * 256 + d[1]) / 4.0 },
        Pid(0x0D, "Greitis", "km/h", 0) { d -> d[0].toDouble() },
        Pid(0x05, "Aušinimo skystis", "°C", 0) { d -> d[0] - 40.0 },
        Pid(0x0F, "Įsiurbiamas oras", "°C", 0) { d -> d[0] - 40.0 },
        Pid(0x04, "Variklio apkrova", "%", 0) { d -> d[0] * 100.0 / 255 },
        Pid(0x11, "Droselis", "%", 0) { d -> d[0] * 100.0 / 255 },
        Pid(0x0B, "Kolektoriaus slėgis", "kPa", 0) { d -> d[0].toDouble() },
        Pid(0x10, "Oro srautas (MAF)", "g/s", 1) { d -> (d[0] * 256 + d[1]) / 100.0 },
        Pid(0x0E, "Uždegimo kampas", "°", 1) { d -> d[0] / 2.0 - 64 },
        Pid(0x06, "Kuro korekcija trumpa", "%", 1) { d -> (d[0] - 128) * 100.0 / 128 },
        Pid(0x07, "Kuro korekcija ilga", "%", 1) { d -> (d[0] - 128) * 100.0 / 128 },
        Pid(0x14, "Lambda 1 įtampa", "V", 3) { d -> d[0] / 200.0 },
        Pid(0x15, "Lambda 2 įtampa", "V", 3) { d -> d[0] / 200.0 },
        Pid(0x42, "ECU įtampa", "V", 2) { d -> (d[0] * 256 + d[1]) / 1000.0 },
    )

    /** Tekstinė eilutė -> baitų masyvas. Grąžina null, jei eilutė ne hex duomenys. */
    fun hexBytes(line: String): IntArray? {
        val s = line.replace(" ", "")
        if (s.isEmpty() || s.length % 2 != 0) return null
        if (!s.all { it in '0'..'9' || it in 'A'..'F' || it in 'a'..'f' }) return null
        return IntArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16) }
    }

    /** Ištraukia Mode 01 PID duomenų baitus iš atsakymo (pvz. "41 0C 1A F8" -> [1A, F8]). */
    fun parseMode01(lines: List<String>, pid: Int): IntArray? {
        for (line in lines) {
            val b = hexBytes(stripFramePrefix(line)) ?: continue
            for (i in 0 until b.size - 1) {
                if (b[i] == 0x41 && b[i + 1] == pid) return b.copyOfRange(i + 2, b.size)
            }
        }
        return null
    }

    /** Palaikomų PID bitų kaukė iš 0100/0120/0140 atsakymų. */
    fun supportedFromMask(base: Int, data: IntArray): Set<Int> {
        val res = mutableSetOf<Int>()
        for (i in 0 until 32) {
            val byte = data.getOrNull(i / 8) ?: break
            if (byte and (0x80 shr (i % 8)) != 0) res.add(base + i + 1)
        }
        return res
    }

    /** CAN kelių kadrų atsakymuose eilutės prasideda "0:", "1:" ... */
    private fun stripFramePrefix(line: String): String {
        val idx = line.indexOf(':')
        return if (idx in 1..2) line.substring(idx + 1).trim() else line
    }

    /**
     * Klaidų kodų dekodavimas (Mode 03 – išsaugotos, 07 – laukiančios).
     * ISO 9141 / KWP: kiekviena eilutė "43 AA BB CC DD EE FF" (3 kodai).
     * CAN: "43 NN AA BB ..." kur NN – kodų skaičius; gali būti keli kadrai.
     */
    fun parseDtcs(lines: List<String>, mode: Int, isCan: Boolean): List<String> {
        val resp = 0x40 + mode
        val codes = linkedSetOf<String>()

        if (isCan) {
            val messages = mutableListOf<MutableList<Int>>()
            for (raw in lines) {
                val idx = raw.indexOf(':')
                val framed = idx in 1..2
                val bytes = hexBytes(if (framed) raw.substring(idx + 1) else raw) ?: continue
                // pirmoji kelių kadrų eilutė (pvz. "00E") – ilgis, praleidžiam (nelyginis ilgis -> null)
                val frameNo = if (framed) raw.substring(0, idx).trim().toIntOrNull(16) ?: 0 else 0
                if (frameNo == 0 || messages.isEmpty()) messages.add(bytes.toMutableList())
                else messages.last().addAll(bytes.toList())
            }
            for (m in messages) {
                val start = m.indexOf(resp)
                if (start < 0 || start + 1 >= m.size) continue
                val count = m[start + 1]
                var i = start + 2
                var n = 0
                while (i + 1 < m.size && n < count) {
                    if (m[i] != 0 || m[i + 1] != 0) codes.add(decodeDtc(m[i], m[i + 1]))
                    i += 2; n++
                }
            }
        } else {
            for (line in lines) {
                val b = hexBytes(line) ?: continue
                if (b.isEmpty() || b[0] != resp) continue
                var i = 1
                while (i + 1 < b.size) {
                    if (b[i] != 0 || b[i + 1] != 0) codes.add(decodeDtc(b[i], b[i + 1]))
                    i += 2
                }
            }
        }
        return codes.toList()
    }

    fun decodeDtc(a: Int, b: Int): String {
        val letter = "PCBU"[(a shr 6) and 0x3]
        val d1 = (a shr 4) and 0x3
        val d2 = a and 0xF
        return String.format("%c%d%X%02X", letter, d1, d2, b)
    }

    /** VIN iš 0902 atsakymo (veikia ne visuose senesniuose automobiliuose). */
    fun parseVin(lines: List<String>): String? {
        val all = mutableListOf<Int>()
        for (raw in lines) {
            val idx = raw.indexOf(':')
            val b = hexBytes(if (idx in 1..2) raw.substring(idx + 1) else raw) ?: continue
            all.addAll(b.toList())
        }
        val text = all.filter { it in 0x30..0x5A }.map { it.toChar() }.joinToString("")
        // VIN – 17 simbolių; imam paskutinius 17 (priekyje gali būti "49 02 01" ir pan.)
        return if (text.length >= 17) text.takeLast(17) else null
    }

    /** Dažniausių bendrinių kodų aprašymai. Volvo gamintojo kodai – kitame etape. */
    val DTC_TEXT = mapOf(
        "P0100" to "Oro srauto (MAF) jutiklio grandinė",
        "P0101" to "Oro srauto (MAF) jutiklio diapazonas / veikimas",
        "P0102" to "Oro srauto (MAF) jutiklio žemas signalas",
        "P0103" to "Oro srauto (MAF) jutiklio aukštas signalas",
        "P0110" to "Įsiurbiamo oro temperatūros jutiklio grandinė",
        "P0115" to "Aušinimo skysčio temperatūros jutiklio grandinė",
        "P0120" to "Droselio padėties jutiklio grandinė",
        "P0130" to "Lambda zondo (1 blokas, 1 jutiklis) grandinė",
        "P0133" to "Lambda zondas (B1S1) lėtai reaguoja",
        "P0135" to "Lambda zondo (B1S1) šildytuvo grandinė",
        "P0141" to "Lambda zondo (B1S2) šildytuvo grandinė",
        "P0171" to "Per liesas mišinys (1 blokas)",
        "P0172" to "Per riebus mišinys (1 blokas)",
        "P0300" to "Atsitiktiniai uždegimo praleidimai",
        "P0301" to "Uždegimo praleidimai 1 cilindre",
        "P0302" to "Uždegimo praleidimai 2 cilindre",
        "P0303" to "Uždegimo praleidimai 3 cilindre",
        "P0304" to "Uždegimo praleidimai 4 cilindre",
        "P0305" to "Uždegimo praleidimai 5 cilindre",
        "P0335" to "Alkūninio veleno padėties jutiklio grandinė",
        "P0340" to "Skirstomojo veleno padėties jutiklio grandinė",
        "P0420" to "Katalizatoriaus efektyvumas žemiau ribos (1 blokas)",
        "P0440" to "Degalų garų (EVAP) sistemos gedimas",
        "P0442" to "EVAP sistemoje mažas nuotėkis",
        "P0455" to "EVAP sistemoje didelis nuotėkis",
        "P0500" to "Greičio jutiklio gedimas",
        "P0505" to "Tuščiosios eigos valdymo sistema",
        "P0700" to "Pavarų dėžės valdymo modulis praneša apie klaidą",
    )
}
