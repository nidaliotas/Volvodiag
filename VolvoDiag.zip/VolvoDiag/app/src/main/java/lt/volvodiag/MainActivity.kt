package lt.volvodiag

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val elm = Elm327()
    private val worker = Executors.newSingleThreadExecutor()   // visos ELM komandos – po vieną
    private val main = Handler(Looper.getMainLooper())

    private lateinit var status: TextView
    private lateinit var content: FrameLayout

    private val log = StringBuilder()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Volatile private var liveRunning = false
    private var supportedPids: Set<Int> = emptySet()
    private var connectedName = ""

    // ---------------------------------------------------------------- gyvavimo ciklas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        elm.logger = { line -> addLog(line) }

        val root = vbox()
        status = tv("Neprisijungta", 15f).apply {
            setBackgroundColor(Color.parseColor("#1F3A5F"))
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(status)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav.addView(btn("Adapteris") { showConnect() })
        nav.addView(btn("Klaidos") { showDtc() })
        nav.addView(btn("Gyvi duomenys") { showLive() })
        nav.addView(btn("Terminalas") { showTerminal() })
        nav.addView(btn("Žurnalas") { showLog() })
        root.addView(HorizontalScrollView(this).apply { addView(nav) })

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        requestBtPermission()
        showConnect()
    }

    override fun onDestroy() {
        liveRunning = false
        worker.shutdownNow()
        Thread { elm.close() }.start()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- leidimai

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun requestBtPermission() {
        if (!hasBtPermission() && Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        showConnect()
    }

    // ---------------------------------------------------------------- 1. Adapteris

    @SuppressLint("MissingPermission")
    private fun showConnect() {
        stopLive()
        val box = screen()
        box.addView(header("Bluetooth adapteris"))
        box.addView(tv("1. Įjunkite degimą (II padėtis) ir įkiškite adapterį į OBD lizdą.\n" +
                "2. Telefono Bluetooth nustatymuose suporuokite adapterį (PIN dažniausiai 1234 arba 0000).\n" +
                "3. Pasirinkite jį žemiau.", 14f))

        if (!hasBtPermission()) {
            box.addView(btn("Suteikti Bluetooth leidimą") { requestBtPermission() })
            return
        }
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null) { box.addView(tv("Šis telefonas neturi Bluetooth.")); return }
        if (!adapter.isEnabled) { box.addView(tv("Įjunkite Bluetooth ir grįžkite čia.")); }

        if (elm.isConnected) {
            box.addView(tv("Prisijungta prie: $connectedName", 15f).apply { setTypeface(null, Typeface.BOLD) })
            box.addView(btn("Atsijungti") {
                bg { elm.close(); ui { setStatus("Neprisijungta"); showConnect() } }
            })
        }

        val devices = adapter.bondedDevices?.toList().orEmpty()
            .sortedByDescending { looksLikeObd(it.name ?: "") }
        if (devices.isEmpty()) box.addView(tv("Nėra suporuotų įrenginių."))
        for (d in devices) {
            val name = d.name ?: "(be pavadinimo)"
            val label = (if (looksLikeObd(name)) "★ " else "") + "$name\n${d.address}"
            box.addView(btn(label) { connect(d) })
        }
        box.addView(btn("Atnaujinti sąrašą") { showConnect() })
    }

    private fun looksLikeObd(n: String) =
        listOf("OBD", "ELM", "V-LINK", "VLINK", "VGATE", "ICAR", "KONNWEI", "OBDLINK", "CAN").any { n.uppercase().contains(it) }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        connectedName = device.name ?: device.address
        setStatus("Jungiamasi prie $connectedName…")
        bg {
            elm.connect(device)
            ui { setStatus("Bluetooth OK, ruošiamas adapteris…") }
            val ver = elm.initialize()
            val volt = elm.send("ATRV")
            ui { setStatus("Adapteris: $ver ($volt). Ieškomas automobilio protokolas…") }
            val proto = elm.detectProtocol()
            supportedPids = readSupportedPids()
            ui {
                setStatus("✔ $connectedName | $proto | akum. $volt")
                toast("Prisijungta. Palaikoma PID: ${supportedPids.size}")
                showDtc()
            }
        }
    }

    private fun readSupportedPids(): Set<Int> {
        val res = mutableSetOf<Int>()
        for (base in listOf(0x00, 0x20, 0x40)) {
            if (base != 0 && !res.contains(base)) break     // kitas blokas palaikomas tik jei nurodytas
            val lines = elm.sendLines(String.format("01%02X", base), 8000)
            val data = Obd.parseMode01(lines, base) ?: break
            res.addAll(Obd.supportedFromMask(base, data))
        }
        return res
    }

    // ---------------------------------------------------------------- 2. Klaidos

    private fun showDtc() {
        stopLive()
        val box = screen()
        box.addView(header("Variklio klaidų kodai (OBD-II)"))
        val out = tv("Paspauskite „Skaityti klaidas“.", 15f)
        box.addView(btn("Skaityti klaidas") { readDtcs(out) })
        box.addView(btn("Variklio būsena ir VIN") { readInfo(out) })
        box.addView(btn("Ištrinti klaidas…") { confirmClear(out) })
        box.addView(out)
        box.addView(tv("Pastaba: čia rodomos tik variklio (OBD-II) klaidos. Volvo moduliai " +
                "(CEM, ABS, SRS, pavarų dėžė ir kt.) bus kitame etape.", 12f).apply { setTextColor(Color.GRAY) })
    }

    private fun readDtcs(out: TextView) {
        if (!requireConnected()) return
        out.text = "Skaitoma…"
        bg {
            val stored = Obd.parseDtcs(elm.sendLines("03", 10000).filterNot { elm.isError(it) }, 3, elm.isCan)
            val pending = Obd.parseDtcs(elm.sendLines("07", 10000).filterNot { elm.isError(it) }, 7, elm.isCan)
            val sb = StringBuilder()
            sb.append("Išsaugotos klaidos (${stored.size}):\n")
            if (stored.isEmpty()) sb.append("  nėra\n") else stored.forEach { sb.append("  ${dtcLine(it)}\n") }
            sb.append("\nLaukiančios (dar nepatvirtintos) klaidos (${pending.size}):\n")
            if (pending.isEmpty()) sb.append("  nėra\n") else pending.forEach { sb.append("  ${dtcLine(it)}\n") }
            ui { out.text = sb.toString() }
        }
    }

    private fun dtcLine(code: String) = code + (Obd.DTC_TEXT[code]?.let { " – $it" } ?: "")

    private fun readInfo(out: TextView) {
        if (!requireConnected()) return
        out.text = "Skaitoma…"
        bg {
            val sb = StringBuilder()
            val d = Obd.parseMode01(elm.sendLines("0101"), 0x01)
            if (d != null) {
                val mil = d[0] and 0x80 != 0
                val count = d[0] and 0x7F
                sb.append("Check Engine lemputė: ${if (mil) "ĮJUNGTA" else "išjungta"}\n")
                sb.append("Klaidų skaičius: $count\n")
            } else sb.append("Variklio būsenos gauti nepavyko.\n")
            val vin = Obd.parseVin(elm.sendLines("0902", 8000))
            sb.append("VIN: ${vin ?: "automobilis nepateikia (įprasta 2003 m. modeliams)"}\n")
            sb.append("Protokolas: ${elm.send("ATDP")}\n")
            sb.append("Akumuliatorius (adapterio matavimas): ${elm.send("ATRV")}\n")
            sb.append("Palaikomi PID: ${supportedPids.sorted().joinToString(" ") { String.format("%02X", it) }}")
            ui { out.text = sb.toString() }
        }
    }

    private fun confirmClear(out: TextView) {
        if (!requireConnected()) return
        AlertDialog.Builder(this)
            .setTitle("Ištrinti klaidas?")
            .setMessage("Bus ištrinti variklio klaidų kodai ir išjungta Check Engine lemputė. " +
                    "Kartu išsitrina ir parengties testų (readiness) duomenys. Variklis turi būti išjungtas, degimas įjungtas.")
            .setPositiveButton("Ištrinti") { _, _ ->
                bg {
                    val r = elm.send("04", 10000)
                    ui { out.text = if (r.contains("44")) "Klaidos ištrintos." else "Atsakymas: $r" }
                }
            }
            .setNegativeButton("Atšaukti", null)
            .show()
    }

    // ---------------------------------------------------------------- 3. Gyvi duomenys

    private fun showLive() {
        stopLive()
        val box = screen()
        box.addView(header("Gyvi duomenys"))
        if (!elm.isConnected) { box.addView(tv("Pirmiausia prisijunkite prie adapterio.")); return }

        val pids = Obd.LIVE_PIDS.filter { supportedPids.isEmpty() || it.code in supportedPids }
        val rows = mutableMapOf<Int, TextView>()
        val grid = TableLayout(this).apply { setColumnStretchable(1, true) }
        for (p in pids) {
            val row = TableRow(this)
            row.addView(tv(p.name, 15f))
            val value = tv("—", 20f).apply { gravity = Gravity.END; setTypeface(Typeface.MONOSPACE, Typeface.BOLD) }
            row.addView(value)
            row.addView(tv(p.unit, 14f))
            grid.addView(row)
            rows[p.code] = value
        }
        val battRow = TableRow(this)
        val batt = tv("—", 20f).apply { gravity = Gravity.END; setTypeface(Typeface.MONOSPACE, Typeface.BOLD) }
        battRow.addView(tv("Akumuliatorius", 15f)); battRow.addView(batt); battRow.addView(tv("V", 14f))
        grid.addView(battRow)

        val rate = tv("", 12f).apply { setTextColor(Color.GRAY) }
        val toggle = Button(this).apply { text = "Pradėti"; isAllCaps = false }
        toggle.setOnClickListener {
            if (liveRunning) { stopLive(); toggle.text = "Pradėti" }
            else { toggle.text = "Sustabdyti"; startLive(pids, rows, batt, rate) }
        }
        box.addView(toggle)
        box.addView(grid)
        box.addView(rate)
        box.addView(tv("2003 m. XC70 naudoja lėtą K-line OBD ryšį, todėl atnaujinama ~kelis kartus per sekundę.", 12f)
            .apply { setTextColor(Color.GRAY) })
    }

    private fun startLive(pids: List<Obd.Pid>, rows: Map<Int, TextView>, batt: TextView, rate: TextView) {
        liveRunning = true
        bg {
            var cycle = 0
            while (liveRunning && elm.isConnected) {
                val t0 = System.currentTimeMillis()
                for (p in pids) {
                    if (!liveRunning) break
                    val lines = elm.sendLines(String.format("01%02X", p.code), 3000)
                    val data = Obd.parseMode01(lines, p.code)
                    val txt = if (data != null && data.size >= 1) {
                        try { String.format(Locale.US, "%.${p.decimals}f", p.calc(data)) } catch (e: Exception) { "?" }
                    } else "n/d"
                    ui { rows[p.code]?.text = txt }
                }
                if (cycle % 5 == 0 && liveRunning) {
                    val v = elm.send("ATRV").replace("V", "")
                    ui { batt.text = v }
                }
                cycle++
                val ms = System.currentTimeMillis() - t0
                ui { rate.text = "Ciklas: $ms ms (${pids.size} parametrai)" }
            }
        }
    }

    private fun stopLive() { liveRunning = false }

    // ---------------------------------------------------------------- 4. Terminalas

    private fun showTerminal() {
        stopLive()
        val box = vbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        content.removeAllViews()
        content.addView(box)

        box.addView(header("Terminalas"))
        box.addView(tv("Tiesioginės ELM327 komandos. Čia bandysime Volvo modulius, kai turėsite adapterį.", 12f)
            .apply { setTextColor(Color.GRAY) })

        val output = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 13f; setTextIsSelectable(true)
            setPadding(dp(6), dp(6), dp(6), dp(6)); setBackgroundColor(Color.parseColor("#F2F2F2"))
        }
        val scroll = ScrollView(this).apply { addView(output) }

        val input = EditText(this).apply {
            hint = "pvz. ATI arba 0100"; isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        fun run(cmd: String) {
            if (cmd.isBlank() || !requireConnected()) return
            output.append("> $cmd\n")
            bg {
                val r = elm.send(cmd.trim().uppercase(), 10000)
                ui { output.append("$r\n\n"); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }
            }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btn("Siųsti") { run(input.text.toString()); input.setText("") })
        box.addView(row)

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in listOf("ATI", "AT@1", "ATRV", "ATDP", "ATDPN", "0100", "03")) quick.addView(btn(c) { run(c) })
        box.addView(HorizontalScrollView(this).apply { addView(quick) })

        box.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    // ---------------------------------------------------------------- 5. Žurnalas

    private fun showLog() {
        stopLive()
        val box = screen()
        box.addView(header("Žurnalas"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("Kopijuoti") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("VolvoDiag log", synchronized(log) { log.toString() }))
            toast("Nukopijuota – galite įklijuoti į pokalbį su Claude")
        })
        row.addView(btn("Išvalyti") { synchronized(log) { log.setLength(0) }; showLog() })
        box.addView(row)
        box.addView(TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true)
            text = synchronized(log) { log.toString().ifEmpty { "(tuščia)" } }
        })
    }

    private fun addLog(line: String) {
        synchronized(log) {
            log.append(timeFmt.format(Date())).append("  ").append(line).append('\n')
            if (log.length > 200_000) log.delete(0, log.length - 150_000)
        }
    }

    // ---------------------------------------------------------------- pagalbinės

    private fun requireConnected(): Boolean {
        if (elm.isConnected) return true
        toast("Pirmiausia prisijunkite prie adapterio")
        return false
    }

    /** Vykdo darbą foninėje gijoje; klaidas rodo vartotojui. */
    private fun bg(block: () -> Unit) {
        worker.execute {
            try {
                block()
            } catch (e: IOException) {
                addLog("KLAIDA: ${e.message}")
                liveRunning = false
                if (!elm.isConnected) elm.close()
                ui { setStatus("⚠ ${e.message}"); toast(e.message ?: "Ryšio klaida") }
            } catch (e: Exception) {
                addLog("KLAIDA: $e")
                ui { toast(e.toString()) }
            }
        }
    }

    private fun ui(block: () -> Unit) { main.post(block) }
    private fun setStatus(s: String) { status.text = s }
    private fun toast(s: String?) = Toast.makeText(this, s ?: "", Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    /** Naujas slenkamas ekranas turinio srityje. */
    private fun screen(): LinearLayout {
        val box = vbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        content.removeAllViews()
        content.addView(ScrollView(this).apply { addView(box) })
        return box
    }

    private fun tv(text: String = "", size: Float = 16f) = TextView(this).apply {
        this.text = text; textSize = size; setPadding(dp(8), dp(4), dp(8), dp(4))
    }

    private fun header(text: String) = tv(text, 20f).apply { setTypeface(null, Typeface.BOLD) }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setOnClickListener { onClick() }
    }
}
