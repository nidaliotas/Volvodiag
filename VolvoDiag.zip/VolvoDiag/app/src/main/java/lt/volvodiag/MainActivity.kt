package lt.volvodiag

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val elm = Elm327()
    private val worker = Executors.newSingleThreadExecutor()   // visos ELM komandos – po vieną
    private val main = Handler(Looper.getMainLooper())
    private lateinit var u: Ui

    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout

    private val log = StringBuilder()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Volatile private var liveRunning = false
    private var supportedPids: Set<Int> = emptySet()
    private var connectedName = ""

    private val volvo = Volvo.Session(elm)
    @Volatile private var obdReady = false          // ar adapteris dabar nustatytas OBD-II režimui
    private var discoveryReceiver: BroadcastReceiver? = null
    private var pendingPair: String? = null
    private val prefs by lazy { getSharedPreferences("volvodiag", Context.MODE_PRIVATE) }

    private enum class Tab(val title: String) {
        ADAPTER("Adapteris"), DTC("Klaidos"), LIVE("Gyvi duomenys"),
        VOLVO("Volvo moduliai"), TERMINAL("Terminalas"), LOG("Žurnalas")
    }
    private var tab = Tab.ADAPTER

    // ---------------------------------------------------------------- gyvavimo ciklas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        u = Ui(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = TW.SLATE_900

        elm.logger = { line -> addLog(line) }

        val root = u.vbox().apply { setBackgroundColor(TW.SLATE_50) }

        // --- antraštė (bg-slate-900)
        val top = u.hbox().apply {
            setBackgroundColor(TW.SLATE_900)
            setPadding(u.dp(16), u.dp(14), u.dp(16), u.dp(14))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_gauge)
            background = u.shape(TW.BLUE_600, 12f)
            setPadding(u.dp(4), u.dp(4), u.dp(4), u.dp(4))
        }
        top.addView(logo, u.lp(w = u.dp(44), h = u.dp(44), r = 12))
        val titles = u.vbox()
        titles.addView(u.text("Volvo Diag", 18f, TW.WHITE, u.bold))
        val statusRow = u.hbox()
        statusDot = View(this).apply { background = u.shape(TW.SLATE_400, 999f) }
        statusRow.addView(statusDot, u.lp(w = u.dp(8), h = u.dp(8), r = 6))
        statusText = u.text("Neprisijungta", 12f, TW.SLATE_400).apply { maxLines = 2 }
        statusRow.addView(statusText, u.lp(w = 0, weight = 1f))
        titles.addView(statusRow)
        top.addView(titles, u.lp(w = 0, weight = 1f))
        top.addView(u.text("XC70 · P2", 11f, TW.SLATE_400, u.medium).apply {
            setPadding(u.dp(8), u.dp(3), u.dp(8), u.dp(3))
            background = u.shape(TW.SLATE_800, 999f, TW.SLATE_700)
        })
        root.addView(top)

        // --- skirtukai (pill)
        nav = u.hbox().apply { setPadding(u.dp(12), u.dp(10), u.dp(12), u.dp(10)) }
        val navScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(TW.WHITE)
            elevation = u.dpf(2f)
            addView(nav)
        }
        root.addView(navScroll)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        requestBtPermission()
        open(Tab.ADAPTER)
    }

    override fun onDestroy() {
        stopDiscovery()
        liveRunning = false
        worker.shutdownNow()
        Thread { elm.close() }.start()
        super.onDestroy()
    }

    private fun renderNav() {
        nav.removeAllViews()
        for (t in Tab.values()) {
            nav.addView(u.chip(t.title, t == tab) { open(t) }, u.lp(w = ViewGroup.LayoutParams.WRAP_CONTENT, r = 8))
        }
    }

    private fun open(t: Tab) {
        if (t != Tab.ADAPTER) stopDiscovery()
        stopLive()
        tab = t
        renderNav()
        when (t) {
            Tab.ADAPTER -> showConnect()
            Tab.DTC -> showDtc()
            Tab.LIVE -> showLive()
            Tab.VOLVO -> showVolvo()
            Tab.TERMINAL -> showTerminal()
            Tab.LOG -> showLog()
        }
    }

    // ---------------------------------------------------------------- būsena

    private enum class St { IDLE, BUSY, OK, ERR }

    private fun setStatus(s: String, st: St = St.BUSY) {
        statusText.text = s
        val c = when (st) { St.IDLE -> TW.SLATE_400; St.BUSY -> TW.AMBER_400; St.OK -> TW.EMERALD_400; St.ERR -> TW.RED_400 }
        statusDot.background = u.shape(c, 999f)
        statusText.setTextColor(if (st == St.ERR) TW.RED_400 else TW.SLATE_300)
    }

    // ---------------------------------------------------------------- leidimai

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 || has(Manifest.permission.BLUETOOTH_CONNECT)

    private fun scanPermissions(): List<String> =
        if (Build.VERSION.SDK_INT >= 31) listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else listOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun requestBtPermission() {
        if (!hasBtPermission() && Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (tab == Tab.ADAPTER) showConnect()
    }

    // ---------------------------------------------------------------- 1. Adapteris

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    @SuppressLint("MissingPermission")
    private fun showConnect() {
        val box = screen()

        val intro = u.card()
        intro.addView(u.eyebrow("Bluetooth adapteris"))
        intro.addView(u.h1(if (elm.isConnected) "Prisijungta" else "Prisijunkite prie adapterio"), u.lp(t = 4))
        intro.addView(u.body("Įkiškite ELM327 adapterį į OBD lizdą (po vairu) ir įjunkite degimą – II padėtis."), u.lp(t = 6))
        box.addView(intro)

        if (!hasBtPermission()) {
            intro.addView(u.button("Suteikti Bluetooth leidimą") { requestBtPermission() }, u.lp(t = 14))
            return
        }
        val adapter = adapter()
        if (adapter == null) { intro.addView(u.badge("Telefonas neturi Bluetooth", Tone.RED), u.lp(ViewGroup.LayoutParams.WRAP_CONTENT, t = 12)); return }
        if (!adapter.isEnabled) intro.addView(u.badge("Įjunkite Bluetooth", Tone.AMBER), u.lp(ViewGroup.LayoutParams.WRAP_CONTENT, t = 12))

        if (elm.isConnected) {
            intro.addView(u.hbox().apply {
                addView(u.badge("● $connectedName", Tone.GREEN))
            }, u.lp(t = 12))
            intro.addView(u.button("Atsijungti", Btn.SECONDARY) {
                bg { elm.close(); obdReady = false; ui { setStatus("Neprisijungta", St.IDLE); showConnect() } }
            }, u.lp(t = 12))
        }

        val devices = adapter.bondedDevices?.toList().orEmpty().sortedByDescending { looksLikeObd(it.name ?: "") }
        val last = prefs.getString("last_addr", null)
        val lastDev = devices.firstOrNull { it.address == last }
        if (lastDev != null && !elm.isConnected) {
            intro.addView(u.button("Jungtis prie ${lastDev.name ?: lastDev.address}") { connect(lastDev) }, u.lp(t = 14))
        }

        val paired = u.card()
        paired.addView(u.h2("Suporuoti įrenginiai"))
        if (devices.isEmpty()) paired.addView(u.muted("Nėra suporuotų įrenginių – raskite adapterį žemiau."), u.lp(t = 6))
        for ((i, d) in devices.withIndex()) {
            if (i > 0) paired.addView(u.divider())
            paired.addView(deviceRow(d) { connect(d) }, u.lp(t = if (i == 0) 8 else 0))
        }
        box.addView(paired)

        val scan = u.card()
        scan.addView(u.h2("Nauji įrenginiai"))
        scan.addView(u.muted("Paieška rodo šalia esančius Bluetooth įrenginius. Adapteris dažniausiai vadinasi OBDII, OBD2 arba V-LINK."), u.lp(t = 4))
        val info = u.muted("")
        val found = u.vbox()
        scan.addView(u.button("Ieškoti aplinkui", Btn.GHOST) { startDiscovery(found, info) }, u.lp(t = 12))
        scan.addView(info, u.lp(t = 8))
        scan.addView(found)
        box.addView(scan)
    }

    @SuppressLint("MissingPermission")
    private fun deviceRow(d: BluetoothDevice, onClick: () -> Unit): View {
        val name = d.name ?: "(be pavadinimo)"
        return u.hbox().apply {
            setPadding(u.dp(4), u.dp(8), u.dp(4), u.dp(8))
            background = u.ripple(TW.WHITE, 8f)
            isClickable = true
            setOnClickListener { onClick() }
            val texts = u.vbox()
            texts.addView(u.text(name, 15f, TW.SLATE_900, u.medium))
            texts.addView(u.monoText(d.address, 12f, TW.SLATE_500))
            addView(texts, u.lp(w = 0, weight = 1f))
            if (looksLikeObd(name)) addView(u.badge("OBD", Tone.BLUE))
            addView(u.text("›", 22f, TW.SLATE_400), u.lp(ViewGroup.LayoutParams.WRAP_CONTENT, l = 10))
        }
    }

    private fun looksLikeObd(n: String) =
        listOf("OBD", "ELM", "V-LINK", "VLINK", "VGATE", "ICAR", "KONNWEI", "OBDLINK", "CAN").any { n.uppercase().contains(it) }

    // ---------------------------------------------------------------- Bluetooth paieška

    @SuppressLint("MissingPermission")
    private fun startDiscovery(list: LinearLayout, info: TextView) {
        val missing = scanPermissions().filterNot { has(it) }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 2); return }
        val adapter = adapter() ?: return
        if (!adapter.isEnabled) { toast("Įjunkite Bluetooth"); return }
        stopDiscovery()
        list.removeAllViews()
        val seen = mutableSetOf<String>()

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                when (intent.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        @Suppress("DEPRECATION")
                        val d: BluetoothDevice = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
                        if (!seen.add(d.address)) return
                        val row = deviceRow(d) { pairAndConnect(d) }
                        if (looksLikeObd(d.name ?: "")) list.addView(row, 0) else list.addView(row)
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> info.text = "Paieška baigta. Rasta įrenginių: ${seen.size}"
                    BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                        @Suppress("DEPRECATION")
                        val d: BluetoothDevice = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
                        val state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1)
                        if (d.address == pendingPair && state == BluetoothDevice.BOND_BONDED) {
                            pendingPair = null; toast("Suporuota"); connect(d)
                        } else if (d.address == pendingPair && state == BluetoothDevice.BOND_NONE) {
                            pendingPair = null; toast("Suporuoti nepavyko (PIN: 1234 arba 0000)")
                        }
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, filter)
        discoveryReceiver = receiver
        val ok = adapter.startDiscovery()
        info.text = if (ok) "Ieškoma (~12 s)…" + (if (Build.VERSION.SDK_INT < 31) " Turi būti įjungta vietovė (GPS)." else "")
                    else "Paieškos pradėti nepavyko. Įjunkite vietovę (GPS) ir bandykite dar kartą."
    }

    @SuppressLint("MissingPermission")
    private fun pairAndConnect(d: BluetoothDevice) {
        try { adapter()?.cancelDiscovery() } catch (_: SecurityException) {}
        if (d.bondState == BluetoothDevice.BOND_BONDED) { connect(d); return }
        pendingPair = d.address
        toast("Poruojama… Jei paklaus PIN, įveskite 1234 arba 0000")
        if (!d.createBond()) { pendingPair = null; toast("Nepavyko pradėti poravimo") }
    }

    @SuppressLint("MissingPermission")
    private fun stopDiscovery() {
        discoveryReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        discoveryReceiver = null
        try { adapter()?.cancelDiscovery() } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- prisijungimas

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        stopDiscovery()
        connectedName = device.name ?: device.address
        prefs.edit().putString("last_addr", device.address).apply()
        setStatus("Jungiamasi prie $connectedName…")
        obdReady = false
        bg {
            elm.connect(device)
            ui { setStatus("Bluetooth OK, ruošiamas adapteris…") }
            val ver = elm.initialize()
            val volt = elm.send("ATRV")
            ui { setStatus("$ver · $volt · ieškomas protokolas…") }
            val proto = elm.detectProtocol()
            supportedPids = readSupportedPids()
            obdReady = true
            ui {
                setStatus("$connectedName · ${proto.removePrefix("AUTO, ")} · $volt", St.OK)
                toast("Prisijungta")
                open(Tab.DTC)
            }
        }
    }

    /** Grąžina adapterį į OBD-II režimą (po Volvo skenavimo). Kviesti foninėje gijoje. */
    private fun ensureObd() {
        if (obdReady) return
        ui { setStatus("Grąžinamas OBD-II režimas…") }
        elm.initialize()
        val proto = elm.detectProtocol()
        if (supportedPids.isEmpty()) supportedPids = readSupportedPids()
        obdReady = true
        ui { setStatus("$connectedName · ${proto.removePrefix("AUTO, ")}", St.OK) }
    }

    private fun readSupportedPids(): Set<Int> {
        val res = mutableSetOf<Int>()
        for (base in listOf(0x00, 0x20, 0x40)) {
            if (base != 0 && !res.contains(base)) break     // kitas blokas palaikomas tik jei nurodytas
            val lines = elm.sendLines(String.format("01%02X", base), 8000)
            val data = Obd.parseMode01(lines, base) ?: break
            res.addAll(Obd.supportedFromMask(base, data))
        }
        return res
    }

    // ---------------------------------------------------------------- 2. Klaidos

    private fun showDtc() {
        val box = screen()
        val head = u.card()
        head.addView(u.eyebrow("OBD-II"))
        head.addView(u.h1("Variklio klaidos"), u.lp(t = 4))
        head.addView(u.body("Standartiniai variklio klaidų kodai ir Check Engine lemputė."), u.lp(t = 6))
        val results = u.vbox()
        head.addView(u.button("Skaityti klaidas") { readDtcs(results) }, u.lp(t = 14))
        val row = u.hbox()
        row.addView(u.button("Būsena ir VIN", Btn.SECONDARY) { readInfo(results) }, u.lp(w = 0, weight = 1f, r = 6))
        row.addView(u.button("Ištrinti…", Btn.DANGER) { confirmClear(results) }, u.lp(w = 0, weight = 1f, l = 6))
        head.addView(row, u.lp(t = 8))
        box.addView(head)
        box.addView(results)

        val note = u.card().apply { background = u.shape(TW.BLUE_50, 14f, TW.BLUE_100); elevation = 0f }
        note.addView(u.text("Geltonas trikampis ant skydelio?", 14f, TW.BLUE_700, u.medium))
        note.addView(u.text("Jį dažniausiai įjungia kiti moduliai (CEM, ABS, skydelis). Juos rasite skiltyje „Volvo moduliai“. " +
                "Pranešimo tekstą skydelyje parodo kairiosios rankenėlės mygtukas READ.", 13f, TW.BLUE_700), u.lp(t = 4))
        box.addView(note)
    }

    private fun loading(container: LinearLayout, msg: String = "Skaitoma…") {
        container.removeAllViews()
        val c = u.card()
        val r = u.hbox()
        r.addView(ProgressBar(this).apply { indeterminateTintList = ColorStateList.valueOf(TW.BLUE_600) }, u.lp(u.dp(22), u.dp(22), r = 12))
        r.addView(u.body(msg))
        c.addView(r)
        container.addView(c)
    }

    private fun readDtcs(container: LinearLayout) {
        if (!requireConnected()) return
        loading(container)
        bg {
            ensureObd()
            val stored = Obd.parseDtcs(elm.sendLines("03", 10000).filterNot { elm.isError(it) }, 3, elm.isCan)
            val pending = Obd.parseDtcs(elm.sendLines("07", 10000).filterNot { elm.isError(it) }, 7, elm.isCan)
            ui {
                container.removeAllViews()
                container.addView(dtcCard("Išsaugotos klaidos", stored, Tone.RED))
                container.addView(dtcCard("Laukiančios (nepatvirtintos)", pending, Tone.AMBER))
            }
        }
    }

    private fun dtcCard(title: String, codes: List<String>, tone: Tone): View {
        val c = u.card()
        val h = u.hbox()
        h.addView(u.h2(title), u.lp(w = 0, weight = 1f))
        h.addView(u.badge(codes.size.toString(), if (codes.isEmpty()) Tone.GREEN else tone))
        c.addView(h)
        if (codes.isEmpty()) {
            c.addView(u.text("✓  Klaidų nėra", 14f, TW.EMERALD_700, u.medium), u.lp(t = 10))
        }
        for (code in codes) {
            c.addView(u.divider())
            val r = u.hbox()
            r.addView(u.badge(code, tone).apply { typeface = u.mono }, u.lp(ViewGroup.LayoutParams.WRAP_CONTENT, r = 12))
            r.addView(u.body(Obd.DTC_TEXT[code] ?: "Aprašymo nėra – ieškokite internete"), u.lp(w = 0, weight = 1f))
            c.addView(r)
        }
        return c
    }

    private fun readInfo(container: LinearLayout) {
        if (!requireConnected()) return
        loading(container)
        bg {
            ensureObd()
            val d = Obd.parseMode01(elm.sendLines("0101"), 0x01)
            val vin = Obd.parseVin(elm.sendLines("0902", 8000))
            val proto = elm.send("ATDP")
            val volt = elm.send("ATRV")
            ui {
                container.removeAllViews()
                val c = u.card()
                c.addView(u.h2("Automobilio būsena"))
                c.addView(u.spacer(6))
                if (d != null) {
                    val mil = d[0] and 0x80 != 0
                    val r = u.hbox().apply { setPadding(0, u.dp(6), 0, u.dp(6)) }
                    r.addView(u.text("Check Engine", 14f, TW.SLATE_500), u.lp(w = 0, weight = 1f))
                    r.addView(u.badge(if (mil) "Įjungta" else "Išjungta", if (mil) Tone.RED else Tone.GREEN))
                    c.addView(r)
                    c.addView(u.kv("Klaidų skaičius", (d[0] and 0x7F).toString()))
                } else c.addView(u.kv("Variklio būsena", "nepavyko gauti", TW.SLATE_400))
                c.addView(u.kv("VIN", vin ?: "nepateikia", if (vin == null) TW.SLATE_400 else TW.SLATE_900))
                c.addView(u.kv("Protokolas", proto))
                c.addView(u.kv("Akumuliatorius", volt))
                c.addView(u.divider())
                c.addView(u.muted("Palaikomi PID: " + supportedPids.sorted().joinToString(" ") { String.format("%02X", it) }))
                container.addView(c)
            }
        }
    }

    private fun confirmClear(container: LinearLayout) {
        if (!requireConnected()) return
        AlertDialog.Builder(this)
            .setTitle("Ištrinti klaidas?")
            .setMessage("Bus ištrinti variklio klaidų kodai ir išjungta Check Engine lemputė. " +
                    "Kartu išsitrina ir parengties testų (readiness) duomenys. Variklis turi būti išjungtas, degimas įjungtas.")
            .setPositiveButton("Ištrinti") { _, _ ->
                loading(container, "Trinama…")
                bg {
                    ensureObd()
                    val r = elm.send("04", 10000)
                    ui {
                        container.removeAllViews()
                        val c = u.card()
                        c.addView(if (r.contains("44")) u.badge("✓ Klaidos ištrintos", Tone.GREEN) else u.badge("Atsakymas: $r", Tone.AMBER),
                            u.lp(ViewGroup.LayoutParams.WRAP_CONTENT))
                        container.addView(c)
                    }
                }
            }
            .setNegativeButton("Atšaukti", null)
            .show()
    }

    // ---------------------------------------------------------------- 3. Gyvi duomenys

    private fun showLive() {
        val box = screen()
        val head = u.card()
        head.addView(u.eyebrow("OBD-II realiu laiku"))
        head.addView(u.h1("Gyvi duomenys"), u.lp(t = 4))
        box.addView(head)
        if (!elm.isConnected) {
            head.addView(u.body("Pirmiausia prisijunkite prie adapterio."), u.lp(t = 6))
            return
        }
        val rate = u.muted("2003 m. XC70 OBD ryšys lėtas (K-line) – reikšmės atsinaujina kelis kartus per sekundę.")
        val pids = Obd.LIVE_PIDS.filter { supportedPids.isEmpty() || it.code in supportedPids }
        val values = mutableMapOf<Int, TextView>()

        // 2 stulpelių „stat“ plytelės
        val grid = u.vbox().apply { setPadding(u.dp(6), 0, u.dp(6), 0) }
        val tiles = pids.map { Triple(it.code, it.name, it.unit) } + Triple(-1, "Akumuliatorius", "V")
        for (pair in tiles.chunked(2)) {
            val row = u.hbox()
            for ((code, name, unit) in pair) {
                val t = u.vbox().apply {
                    background = u.shape(TW.WHITE, 14f, TW.SLATE_200)
                    elevation = u.dpf(1f)
                    setPadding(u.dp(14), u.dp(12), u.dp(14), u.dp(12))
                }
                t.addView(u.text(name, 12f, TW.SLATE_500, u.medium).apply { maxLines = 1 })
                val vr = u.hbox().apply { gravity = Gravity.BOTTOM }
                val v = u.text("—", 26f, TW.SLATE_900, u.bold).apply { typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
                vr.addView(v)
                vr.addView(u.text(unit, 13f, TW.SLATE_400, u.medium), u.lp(ViewGroup.LayoutParams.WRAP_CONTENT, l = 4, b = 4))
                t.addView(vr, u.lp(t = 2))
                row.addView(t, u.lp(w = 0, weight = 1f, l = 6, t = 6, r = 6, b = 6))
                values[code] = v
            }
            if (pair.size == 1) row.addView(View(this), u.lp(w = 0, weight = 1f, l = 6, r = 6))
            grid.addView(row)
        }

        lateinit var toggle: TextView
        toggle = u.button("▶  Pradėti") {
            if (liveRunning) {
                stopLive(); toggle.text = "▶  Pradėti"; toggle.background = u.ripple(TW.BLUE_600, 10f, rippleColor = 0x33FFFFFF)
            } else {
                toggle.text = "■  Sustabdyti"; toggle.background = u.ripple(TW.SLATE_900, 10f, rippleColor = 0x33FFFFFF)
                startLive(pids, values, rate)
            }
        }
        head.addView(toggle, u.lp(t = 14))
        head.addView(rate, u.lp(t = 10))
        box.addView(grid)
    }

    private fun startLive(pids: List<Obd.Pid>, values: Map<Int, TextView>, rate: TextView) {
        liveRunning = true
        bg {
            ensureObd()
            var cycle = 0
            while (liveRunning && elm.isConnected) {
                val t0 = System.currentTimeMillis()
                for (p in pids) {
                    if (!liveRunning) break
                    val lines = elm.sendLines(String.format("01%02X", p.code), 3000)
                    val data = Obd.parseMode01(lines, p.code)
                    val txt = if (data != null && data.isNotEmpty()) {
                        try { String.format(Locale.US, "%.${p.decimals}f", p.calc(data)) } catch (e: Exception) { "?" }
                    } else "n/d"
                    ui { values[p.code]?.text = txt }
                }
                if (cycle % 5 == 0 && liveRunning) {
                    val v = elm.send("ATRV").replace("V", "")
                    ui { values[-1]?.text = v }
                }
                cycle++
                val ms = System.currentTimeMillis() - t0
                ui { rate.text = "Ciklas: $ms ms · ${pids.size} parametrai" }
            }
        }
    }

    private fun stopLive() { liveRunning = false }

    // ---------------------------------------------------------------- 4. Volvo moduliai

    private var volvoReport = ""
    private val volvoResults = mutableListOf<Pair<Volvo.Bus, Volvo.Result>>()
    private val volvoScanned = mutableSetOf<Volvo.Bus>()

    private fun showVolvo() {
        val box = screen()
        val head = u.card()
        head.addView(u.hbox().apply {
            addView(u.eyebrow("VIDA protokolas"), u.lp(w = 0, weight = 1f))
            addView(u.badge("Bandomasis", Tone.AMBER))
        })
        head.addView(u.h1("Volvo moduliai"), u.lp(t = 4))
        head.addView(u.body("Klaidos iš CEM, prietaisų skydelio, ABS, pavarų dėžės ir kitų modulių. Tik skaitoma – automobilyje niekas nekeičiama."), u.lp(t = 6))
        box.addView(head)

        box.addView(busCard(Volvo.Bus.HS, "Greitoji CAN", "Variklis, pavarų dėžė, ABS, vairo kampas"))
        box.addView(busCard(Volvo.Bus.LS, "Lėtoji CAN", "CEM, prietaisų skydelis, klimatas, durys, garso sistema"))

        val progressCard = u.card().apply { visibility = View.GONE; id = View.generateViewId() }
        box.addView(progressCard)
        progressHolder = progressCard

        val results = u.vbox()
        resultsHolder = results
        box.addView(results)
        renderVolvoResults()
    }

    private var progressHolder: LinearLayout? = null
    private var resultsHolder: LinearLayout? = null

    private fun busCard(bus: Volvo.Bus, title: String, desc: String): View {
        val c = u.card()
        val h = u.hbox()
        h.addView(u.h2(title), u.lp(w = 0, weight = 1f))
        h.addView(u.badge("Jungiklis ${bus.switchPos}", Tone.BLUE).apply { typeface = u.mono })
        c.addView(h)
        c.addView(u.muted(desc), u.lp(t = 4))
        val r = u.hbox()
        r.addView(u.button("Žinomi moduliai") { volvoScan(bus, false) }, u.lp(w = 0, weight = 1f, r = 6))
        r.addView(u.button("Pilnas 00–7F", Btn.SECONDARY) { volvoScan(bus, true) }, u.lp(w = 0, weight = 1f, l = 6))
        c.addView(r, u.lp(t = 12))
        return c
    }

    private fun volvoScan(bus: Volvo.Bus, full: Boolean) {
        if (!requireConnected()) return
        AlertDialog.Builder(this)
            .setTitle("Adapterio jungiklis")
            .setMessage("Perjunkite adapterio jungiklį į ${bus.switchPos} padėtį ir spauskite „Pradėti“.\n\n" +
                    "Jei adapteris be jungiklio – tiesiog spauskite „Pradėti“." +
                    if (full) "\n\nPilnas skenavimas užtrunka ~30 s." else "")
            .setPositiveButton("Pradėti") { _, _ -> runVolvoScan(bus, full) }
            .setNegativeButton("Atšaukti", null)
            .show()
    }

    private fun runVolvoScan(bus: Volvo.Bus, full: Boolean) {
        val pc = progressHolder ?: return
        pc.visibility = View.VISIBLE
        pc.removeAllViews()
        val label = u.body("Ruošiamas adapteris…")
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(TW.BLUE_600)
            progressBackgroundTintList = ColorStateList.valueOf(TW.SLATE_200)
            max = 100
        }
        pc.addView(label)
        pc.addView(bar, u.lp(t = 10))

        bg {
            obdReady = false
            volvo.setup(bus)
            val addrs = if (full) (0x01..0x7F).toList() else Volvo.KNOWN.filter { it.bus == bus }.map { it.addr }.distinct()
            val found = mutableListOf<Volvo.Result>()
            for ((i, a) in addrs.withIndex()) {
                val msg = String.format("Tikrinamas %02X · %d/%d · rasta %d", a, i + 1, addrs.size, found.size)
                val pct = (i + 1) * 100 / addrs.size
                ui { label.text = msg; bar.progress = pct }
                volvo.readDtcs(a)?.let { found.add(it) }
            }
            val sb = StringBuilder("${bus.title}\nAtsakė modulių: ${found.size}\n")
            for (r in found) {
                sb.append(Volvo.label(r.addr, bus)).append('\n')
                if (r.note.isNotEmpty()) sb.append("   ${r.note}\n")
                if (r.dtcs.isEmpty()) sb.append("   klaidų nėra\n")
                r.dtcs.forEach { sb.append("   $it\n") }
                sb.append("   [ID ${r.respId}: ${r.rawPayload}]\n")
            }
            addLog("=== VOLVO REZULTATAI ===\n$sb")
            ui {
                volvoResults.removeAll { it.first == bus }
                volvoResults.addAll(found.map { bus to it })
                volvoScanned.add(bus)
                volvoReport = buildString {
                    for (b in Volvo.Bus.values()) if (b in volvoScanned) {
                        append(b.title).append('\n')
                        for ((_, r) in volvoResults.filter { it.first == b }) {
                            append(Volvo.label(r.addr, b)).append(": ")
                            append(if (r.dtcs.isEmpty()) "OK" else r.dtcs.joinToString(", "))
                            if (r.note.isNotEmpty()) append(" (${r.note})")
                            append("  [${r.respId}: ${r.rawPayload}]\n")
                        }
                        append('\n')
                    }
                }
                pc.visibility = View.GONE
                if (tab == Tab.VOLVO) renderVolvoResults()
                toast("Baigta: ${found.size} modulių, klaidų: ${found.sumOf { it.dtcs.size }}")
            }
        }
    }

    private fun renderVolvoResults() {
        val holder = resultsHolder ?: return
        holder.removeAllViews()
        for (bus in Volvo.Bus.values()) {
            if (bus !in volvoScanned) continue
            val list = volvoResults.filter { it.first == bus }.map { it.second }
            val c = u.card()
            val h = u.hbox()
            h.addView(u.h2(if (bus == Volvo.Bus.HS) "Greitoji CAN" else "Lėtoji CAN"), u.lp(w = 0, weight = 1f))
            val total = list.sumOf { it.dtcs.size }
            h.addView(u.badge("${list.size} mod. · $total kl.", if (total > 0) Tone.AMBER else Tone.GREEN))
            c.addView(h)
            if (list.isEmpty()) {
                c.addView(u.body("Neatsakė nė vienas modulis. Patikrinkite jungiklio padėtį (${bus.switchPos}), degimą ir ar adapteris palaiko 29 bitų CAN (žr. Žurnalą)."), u.lp(t = 8))
            }
            for (r in list) {
                c.addView(u.divider())
                val m = Volvo.moduleOf(r.addr, bus)
                val row = u.hbox()
                row.addView(u.text(m?.code ?: String.format("%02X", r.addr), 13f, TW.WHITE, u.bold).apply {
                    gravity = Gravity.CENTER
                    background = u.shape(if (r.dtcs.isEmpty()) TW.EMERALD_500 else TW.AMBER_500, 10f)
                }, u.lp(u.dp(48), u.dp(36), r = 12))
                val texts = u.vbox()
                texts.addView(u.text(m?.desc ?: "Nežinomas modulis", 14f, TW.SLATE_900, u.medium))
                texts.addView(u.muted(String.format("Adresas %02X", r.addr) + (if (m != null && !m.sure) " · spėjama" else "")))
                row.addView(texts, u.lp(w = 0, weight = 1f))
                row.addView(when {
                    r.dtcs.isNotEmpty() -> u.badge("${r.dtcs.size} kl.", Tone.AMBER)
                    r.note.startsWith("Neigiamas") || r.note.startsWith("Neatpažintas") -> u.badge("?", Tone.GRAY)
                    else -> u.badge("OK", Tone.GREEN)
                })
                c.addView(row)
                if (r.dtcs.isNotEmpty()) {
                    val codes = u.hbox().apply { setPadding(u.dp(60), u.dp(8), 0, 0) }
                    val flow = u.vbox()
                    r.dtcs.chunked(3).forEach { line ->
                        val lr = u.hbox()
                        line.forEach { lr.addView(u.badge(it, Tone.AMBER).apply { typeface = u.mono }, u.lp(ViewGroup.LayoutParams.WRAP_CONTENT, r = 6, b = 6)) }
                        flow.addView(lr)
                    }
                    codes.addView(flow)
                    c.addView(codes)
                }
                if (r.note.isNotEmpty() && r.note != "AE01") c.addView(u.muted(r.note).apply { setPadding(u.dp(60), u.dp(4), 0, 0) })
            }
            holder.addView(c)
        }
        if (volvoScanned.isNotEmpty()) {
            val c = u.card()
            c.addView(u.button("Kopijuoti rezultatus", Btn.SECONDARY) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Volvo moduliai", volvoReport))
                toast("Nukopijuota – įklijuokite į pokalbį su Claude")
            })
            c.addView(u.muted("Kodai rodomi VIDA formatu (pvz. CEM-1A2B). Aprašymus ir trynimą pridėsime kitoje versijoje."), u.lp(t = 8))
            holder.addView(c)
        }
    }

    // ---------------------------------------------------------------- 5. Terminalas

    private fun showTerminal() {
        content.removeAllViews()
        val box = u.vbox().apply { setPadding(u.dp(12), u.dp(12), u.dp(12), u.dp(12)) }
        content.addView(box)

        val output = u.monoText("", 13f, TW.SLATE_100).apply {
            setTextIsSelectable(true)
            setPadding(u.dp(12), u.dp(12), u.dp(12), u.dp(12))
        }
        val scroll = ScrollView(this).apply {
            background = u.shape(TW.SLATE_900, 14f)
            addView(output)
        }
        output.text = "Volvo Diag terminalas\nSiųskite ELM327 komandas, pvz. ATI, ATRV, 0100\n\n"

        val input = EditText(this).apply {
            hint = "Komanda…"; isSingleLine = true; textSize = 15f; typeface = u.mono
            setTextColor(TW.SLATE_900); setHintTextColor(TW.SLATE_400)
            background = u.shape(TW.WHITE, 10f, TW.SLATE_300)
            setPadding(u.dp(14), u.dp(10), u.dp(14), u.dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        fun run(cmd: String) {
            if (cmd.isBlank() || !requireConnected()) return
            output.append("› $cmd\n")
            val c = cmd.trim().uppercase().replace(" ", "")
            if (c.startsWith("AT") && c !in listOf("ATI", "AT@1", "ATRV", "ATDP", "ATDPN")) obdReady = false
            bg {
                val r = elm.send(cmd.trim().uppercase(), 10000)
                ui { output.append("$r\n\n"); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }
            }
        }
        val row = u.hbox()
        row.addView(input, u.lp(w = 0, weight = 1f, r = 8))
        row.addView(u.button("Siųsti") { run(input.text.toString()); input.setText("") })
        box.addView(row)

        val quick = u.hbox().apply { setPadding(0, u.dp(10), 0, u.dp(10)) }
        for (c in listOf("ATI", "AT@1", "ATRV", "ATDP", "ATDPN", "0100", "03")) {
            quick.addView(u.chip(c) { run(c) }.apply { typeface = u.mono }, u.lp(ViewGroup.LayoutParams.WRAP_CONTENT, r = 8))
        }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(quick) })
        box.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    // ---------------------------------------------------------------- 6. Žurnalas

    private fun showLog() {
        val box = screen()
        val head = u.card()
        head.addView(u.h1("Žurnalas"))
        head.addView(u.body("Visas susirašinėjimas su adapteriu. Atsiųskite jį Claude, jei kas nors neveikia."), u.lp(t = 4))
        val row = u.hbox()
        row.addView(u.button("Dalintis") {
            val text = synchronized(log) { log.toString() }.takeLast(100_000)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Volvo Diag žurnalas")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(send, "Dalintis žurnalu"))
        }, u.lp(w = 0, weight = 1f, r = 4))
        row.addView(u.button("Kopijuoti", Btn.SECONDARY) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("VolvoDiag log", synchronized(log) { log.toString() }.takeLast(100_000)))
            toast("Nukopijuota")
        }, u.lp(w = 0, weight = 1f, l = 4, r = 4))
        row.addView(u.button("Išvalyti", Btn.DANGER) { synchronized(log) { log.setLength(0) }; showLog() }, u.lp(w = 0, weight = 1f, l = 4))
        head.addView(row, u.lp(t = 12))
        box.addView(head)

        val console = u.monoText(synchronized(log) { log.toString().takeLast(30_000).ifEmpty { "(tuščia)" } }, 11f, TW.SLATE_200).apply {
            setTextIsSelectable(true)
            background = u.shape(TW.SLATE_900, 14f)
            setPadding(u.dp(12), u.dp(12), u.dp(12), u.dp(12))
        }
        box.addView(console, u.lp(l = 12, t = 6, r = 12, b = 12))
    }

    private fun addLog(line: String) {
        synchronized(log) {
            log.append(timeFmt.format(Date())).append("  ").append(line).append('\n')
            if (log.length > 200_000) log.delete(0, log.length - 150_000)
        }
    }

    // ---------------------------------------------------------------- pagalbinės

    private fun requireConnected(): Boolean {
        if (elm.isConnected) return true
        toast("Pirmiausia prisijunkite prie adapterio")
        return false
    }

    /** Vykdo darbą foninėje gijoje; klaidas rodo vartotojui. */
    private fun bg(block: () -> Unit) {
        worker.execute {
            try {
                block()
            } catch (e: IOException) {
                addLog("KLAIDA: ${e.message}")
                liveRunning = false
                if (!elm.isConnected) elm.close()
                ui {
                    setStatus(e.message ?: "Ryšio klaida", St.ERR)
                    progressHolder?.visibility = View.GONE
                    toast(e.message ?: "Ryšio klaida")
                }
            } catch (e: Exception) {
                addLog("KLAIDA: $e")
                ui { toast(e.toString()) }
            }
        }
    }

    private fun ui(block: () -> Unit) { main.post(block) }
    private fun toast(s: String?) = Toast.makeText(this, s ?: "", Toast.LENGTH_LONG).show()

    /** Naujas slenkamas ekranas turinio srityje. */
    private fun screen(): LinearLayout {
        val box = u.vbox().apply { setPadding(0, u.dp(8), 0, u.dp(16)) }
        content.removeAllViews()
        content.addView(ScrollView(this).apply { addView(box) })
        return box
    }
}
