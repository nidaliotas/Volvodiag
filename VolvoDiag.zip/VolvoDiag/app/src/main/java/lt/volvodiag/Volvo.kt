package lt.volvodiag

import java.io.IOException

/*
 * Volvo gamintojo diagnostika (VIDA protokolas) per 29 bitų CAN.
 *
 * Užklausa: ID 000FFFFE, duomenys [C8+n] [modulis] [paslauga] [parametrai...] (8 baitai)
 *   AE = skaityti klaidas (atsakymas EE), A6 = skaityti parametrą (atsakymas E6),
 *   neigiamas atsakymas: [modulis] 7F [paslauga] [kodas].
 * Atsakymo kadro pirmas baitas: bit7 = pirmas kadras, bit6 = paskutinis, bit0-2 = naudingų baitų skaičius.
 *
 * Šaltiniai (bendruomenės atvirkštinė inžinerija): Tigo2000/Volvo-VIDA, OBDb/Volvo-V50 #14,
 * hackingvolvo.blogspot.com, waal70blog. Tai NE oficiali Volvo dokumentacija.
 */
object Volvo {

    enum class Bus(val title: String, val switchPos: String) {
        HS("Greitoji CAN (500 kbps, OBD kontaktai 6/14)", "HS"),
        LS("Lėtoji CAN (125 kbps, OBD kontaktai 3/11)", "MS"),
    }

    data class Module(val addr: Int, val code: String, val desc: String, val bus: Bus, val sure: Boolean)

    /* P2 (1999–2007 S60/S80/V70/XC70/XC90) moduliai. sure=false – adresas tikėtinas, bet nepatvirtintas. */
    val KNOWN = listOf(
        Module(0x7A, "ECM", "Variklio valdymas (Bosch ME7)", Bus.HS, true),
        Module(0x11, "ECM", "Variklio valdymas (kiti varikliai)", Bus.HS, false),
        Module(0x6E, "TCM", "Automatinė pavarų dėžė", Bus.HS, true),
        Module(0x01, "BCM", "Stabdžiai / ABS / DSTC", Bus.HS, true),
        Module(0x28, "SAS", "Vairo kampo jutiklis", Bus.HS, true),
        Module(0x50, "CEM", "Centrinis modulis (greitoji sąsaja)", Bus.HS, true),
        Module(0x1A, "AWD", "Visų ratų pavara (Haldex)", Bus.HS, false),
        Module(0x40, "CEM", "Centrinis elektronikos modulis", Bus.LS, true),
        Module(0x51, "DIM", "Prietaisų skydelis", Bus.LS, true),
        Module(0x52, "AEM", "Papildomas elektronikos modulis", Bus.LS, true),
        Module(0x64, "PHM", "Telefono modulis", Bus.LS, true),
        Module(0x58, "SRS", "Oro pagalvės", Bus.LS, false),
        Module(0x29, "CCM", "Klimato kontrolė", Bus.LS, false),
        Module(0x43, "DDM", "Vairuotojo durų modulis", Bus.LS, false),
        Module(0x45, "PDM", "Keleivio durų modulis", Bus.LS, false),
        Module(0x46, "REM", "Galinis elektronikos modulis", Bus.LS, false),
        Module(0x48, "UEM", "Viršutinis elektronikos modulis (stoglangis)", Bus.LS, false),
        Module(0x49, "SWM", "Vairo mygtukų modulis", Bus.LS, false),
        Module(0x2E, "PSM", "Elektrinė sėdynė", Bus.LS, false),
        Module(0x54, "AUM", "Garso sistema", Bus.LS, false),
        Module(0x61, "ICM", "Informacinis modulis / RTI", Bus.LS, false),
    )

    fun moduleOf(addr: Int, bus: Bus? = null): Module? =
        KNOWN.firstOrNull { it.addr == addr && (bus == null || it.bus == bus) } ?: KNOWN.firstOrNull { it.addr == addr }

    fun label(addr: Int, bus: Bus? = null): String {
        val m = moduleOf(addr, bus) ?: return String.format("Modulis %02X", addr)
        return String.format("%02X %s – %s%s", addr, m.code, m.desc, if (m.sure) "" else " (?)")
    }

    // ------------------------------------------------------------------ rezultatai

    data class Result(
        val addr: Int,
        val respId: String,
        val dtcs: List<String>,     // pvz. "CEM-1A2B"
        val rawPayload: String,     // visi atsakymo baitai (Claude analizei)
        val note: String = ""
    )

    // ------------------------------------------------------------------ kadrai

    data class Frame(val id: String, val data: IntArray)

    /* Su ATH1 + ATS1 + CAF0 eilutė atrodo taip: "00 40 00 21 8F 11 EE 11 C3 01 12 0F". */
    fun parseFrames(lines: List<String>): List<Frame> {
        val out = mutableListOf<Frame>()
        for (line in lines) {
            val b = Obd.hexBytes(line) ?: continue
            when {
                b.size >= 12 -> out.add(Frame(b.take(4).joinToString("") { String.format("%02X", it) }, b.copyOfRange(4, 12)))
                b.size == 8 -> out.add(Frame("?", b))
            }
        }
        return out
    }

    /* Sujungia kelis kadrus į pilnus pranešimus (kiekvienam atsakymo ID atskirai). */
    fun assemble(frames: List<Frame>): List<Pair<String, List<Int>>> {
        val result = mutableListOf<Pair<String, List<Int>>>()
        val open = mutableMapOf<String, MutableList<Int>>()
        for (f in frames) {
            val h = f.data[0]
            val count = (h and 0x07).coerceAtMost(7)
            val bytes = f.data.copyOfRange(1, 1 + count).toList()
            if (h and 0x80 != 0) open[f.id] = mutableListOf()
            val buf = open[f.id] ?: continue
            buf.addAll(bytes)
            if (h and 0x40 != 0) {
                result.add(f.id to buf.toList())
                open.remove(f.id)
            }
        }
        // nebaigti pranešimai – vis tiek grąžinam, kad matytųsi žurnale
        open.forEach { (id, buf) -> if (buf.isNotEmpty()) result.add(id to buf.toList()) }
        return result
    }

    private fun hex(list: List<Int>) = list.joinToString(" ") { String.format("%02X", it) }

    // ------------------------------------------------------------------ sesija

    class Session(private val elm: Elm327) {

        var bus: Bus? = null
            private set

        /* Filtrai lėtajai magistralei, jei platus filtras užtvindo adapterį. */
        private var narrowLs = false
        private val lsNarrowFilters = listOf("00400000", "00600000", "00800000")

        private fun must(cmd: String) {
            val r = elm.send(cmd)
            if (r.trim() == "?" || r.contains("ERROR")) throw IOException("Adapteris nepalaiko komandos $cmd (atsakė: $r). Reikia geresnio ELM327 v1.4+ adapterio.")
        }

        fun setup(b: Bus) {
            elm.send("ATPC")           // nutraukti K-line sesiją, jei buvo
            must("ATE0"); must("ATL0"); must("ATS1"); must("ATH1")
            must("ATAT0")
            when (b) {
                Bus.HS -> must("ATSP7")                              // ISO 15765 29 bit 500k
                Bus.LS -> { must("ATPB0004"); must("ATSPB") }        // vartotojo CAN: 29 bit, 500/4 = 125k
            }
            must("ATCAF0")             // jokio ISO-TP formatavimo – siunčiam „žalius“ 8 baitus
            must("ATCP00")
            must("ATSH0FFFFE")         // ID 000FFFFE
            must("ATST32")             // ~200 ms laukimas
            narrowLs = false
            when (b) {
                Bus.HS -> { must("ATCF00400000"); must("ATCM1FFF0000") }
                Bus.LS -> { must("ATCF00000000"); must("ATCM1F000000") }
            }
            bus = b
        }

        /* Grąžina pranešimų sąrašą (atsakymo ID, baitai), kurių pirmas baitas = modulio adresas. */
        private fun request(addr: Int, data: String): List<Pair<String, List<Int>>> {
            val b = bus ?: throw IOException("Magistralė nenustatyta")
            val cmd = String.format("%02X", addr).let { a -> data.replace("{A}", a) }
            if (b == Bus.LS && narrowLs) {
                val all = mutableListOf<Pair<String, List<Int>>>()
                for (f in lsNarrowFilters) {
                    elm.send("ATCF$f"); elm.send("ATCM1FFF0000")
                    all.addAll(sendAndParse(cmd, addr))
                    if (all.isNotEmpty()) break
                }
                return all
            }
            val raw = elm.send(cmd, 4000)
            if (b == Bus.LS && (raw.contains("BUFFER FULL") || raw.split('\n').size > 30)) {
                // per daug transliuojamų kadrų – pereinam prie siaurų filtrų
                narrowLs = true
                return request(addr, data)
            }
            return parse(raw, addr)
        }

        private fun sendAndParse(cmd: String, addr: Int) = parse(elm.send(cmd, 4000), addr)

        private fun parse(raw: String, addr: Int): List<Pair<String, List<Int>>> {
            if (raw.contains("NO DATA") || raw.contains("CAN ERROR")) return emptyList()
            val lines = raw.split('\n').map { it.trim() }
            return assemble(parseFrames(lines)).filter { it.second.isNotEmpty() && it.second[0] == addr }
        }

        /* Klaidų skaitymas. Pirmiausia AE 11, jei modulis nesupranta – AE 01. Null – modulis neatsako. */
        fun readDtcs(addr: Int): Result? {
            val msgs = request(addr, "CB{A}AE1100000000")
            if (msgs.isEmpty()) return null
            var (id, p) = msgs.first()
            var note = ""
            if (p.size >= 3 && p[1] == 0x7F) {
                val alt = request(addr, "CB{A}AE0100000000")
                if (alt.isNotEmpty() && alt.first().second.getOrNull(1) == 0xEE) {
                    id = alt.first().first; p = alt.first().second; note = "AE01"
                } else {
                    return Result(addr, id, emptyList(), hex(p), String.format("Neigiamas atsakymas (kodas %02X)", p.getOrElse(3) { 0 }))
                }
            }
            if (p.size < 3 || p[1] != 0xEE) return Result(addr, id, emptyList(), hex(p), "Neatpažintas atsakymas")
            val code = moduleOf(addr, bus)?.code ?: String.format("M%02X", addr)
            val dtcs = mutableListOf<String>()
            var i = 3
            while (i + 1 < p.size) {
                if (p[i] != 0 || p[i + 1] != 0) dtcs.add(String.format("%s-%02X%02X", code, p[i], p[i + 1]))
                i += 2
            }
            return Result(addr, id, dtcs, hex(p), note)
        }
    }
}
