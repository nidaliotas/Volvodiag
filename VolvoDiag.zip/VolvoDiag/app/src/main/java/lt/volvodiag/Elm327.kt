package lt.volvodiag

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * ELM327 adapterio valdymas per Bluetooth (SPP).
 * Visi metodai blokuojantys – kviesti tik iš foninės gijos.
 */
class Elm327 {

    companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        private val ERRORS = listOf(
            "NO DATA", "UNABLE TO CONNECT", "CAN ERROR", "BUS ERROR",
            "BUS INIT: ...ERROR", "STOPPED", "ERROR", "FB ERROR", "DATA ERROR", "BUFFER FULL"
        )
    }

    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    /** Žurnalo funkcija (kiekviena užklausa ir atsakymas). */
    var logger: ((String) -> Unit)? = null

    /** ELM protokolo numeris (ATDPN), pvz. "3" (ISO 9141) arba "6" (CAN). */
    var protocolNum: String = ""
        private set

    val isConnected: Boolean get() = socket?.isConnected == true

    /** CAN protokolai ELM327 numeracijoje: 6–9 (ir A – SAE J1939). */
    val isCan: Boolean get() = protocolNum.trimStart('A').let { it in listOf("6", "7", "8", "9", "A", "B", "C") }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        close()
        val s: BluetoothSocket = try {
            device.createRfcommSocketToServiceRecord(SPP_UUID).also { it.connect() }
        } catch (first: IOException) {
            // Kai kurie pigūs klonai jungiasi tik per šį „paslėptą“ metodą
            logger?.invoke("Standartinis prisijungimas nepavyko (${first.message}), bandau atsarginį būdą…")
            try {
                val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                (m.invoke(device, 1) as BluetoothSocket).also { it.connect() }
            } catch (e: Exception) {
                throw IOException("Nepavyko prisijungti: ${first.message}")
            }
        }
        socket = s
        input = s.inputStream
        output = s.outputStream
    }

    /** Adapterio paruošimas darbui. Grąžina adapterio versiją (ATI). */
    fun initialize(): String {
        send("ATZ", 3000)          // perkrauti
        Thread.sleep(500)
        send("ATE0")               // be aido
        send("ATL0")               // be eilučių pabaigos simbolių
        send("ATS1")               // tarpai tarp baitų (lengviau skaityti žurnalą)
        send("ATH0")               // be antraščių
        send("ATAT1")              // adaptyvus laukimo laikas
        val version = send("ATI")
        send("ATSP0")              // automatinis protokolo parinkimas
        return version
    }

    /**
     * Suranda automobilio OBD protokolą. Pirmoji užklausa gali užtrukti iki ~10 s
     * (ypač K-line / ISO 9141, kurį naudoja 2003 m. P2 Volvo).
     */
    fun detectProtocol(): String {
        val r = send("0100", 20000)
        if (isError(r)) throw IOException("Automobilis neatsako: $r (ar įjungtas degimas?)")
        protocolNum = send("ATDPN").trim()
        return send("ATDP").trim()
    }

    /** Išsiunčia komandą ir laukia '>' simbolio. Grąžina išvalytą atsakymą. */
    fun send(cmd: String, timeoutMs: Long = 5000): String {
        val inp = input ?: throw IOException("Neprisijungta")
        val out = output ?: throw IOException("Neprisijungta")

        // išmesti senus duomenis
        while (inp.available() > 0) inp.read()

        logger?.invoke(">> $cmd")
        out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
        out.flush()

        val sb = StringBuilder()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            if (inp.available() > 0) {
                val b = inp.read()
                if (b < 0) throw IOException("Ryšys nutrūko")
                val c = b.toChar()
                if (c == '>') break
                sb.append(c)
            } else {
                if (System.currentTimeMillis() > deadline) {
                    logger?.invoke("<< (laikas baigėsi) ${sb.toString().trim()}")
                    throw IOException("Adapteris neatsakė laiku į $cmd")
                }
                Thread.sleep(5)
            }
        }
        val cleaned = clean(sb.toString())
        logger?.invoke("<< " + cleaned.replace("\n", " | "))
        return cleaned
    }

    /** Atsakymo eilutės be tarnybinių pranešimų. */
    fun sendLines(cmd: String, timeoutMs: Long = 5000): List<String> =
        send(cmd, timeoutMs).split('\n').map { it.trim() }.filter { it.isNotEmpty() }

    fun isError(resp: String): Boolean {
        val r = resp.uppercase()
        return r.isBlank() || r.trim() == "?" || ERRORS.any { r.contains(it) }
    }

    private fun clean(raw: String): String =
        raw.replace("\u0000", "")
            .split('\r', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .filterNot { it.startsWith("SEARCHING") || it.startsWith("BUS INIT") && !it.contains("ERROR") }
            .joinToString("\n")

    fun close() {
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        input = null; output = null; socket = null
        protocolNum = ""
    }
}
