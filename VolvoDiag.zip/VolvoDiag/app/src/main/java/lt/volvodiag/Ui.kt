package lt.volvodiag

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Tailwind CSS spalvų paletė. */
object TW {
    const val WHITE = 0xFFFFFFFF.toInt()
    const val SLATE_50 = 0xFFF8FAFC.toInt()
    const val SLATE_100 = 0xFFF1F5F9.toInt()
    const val SLATE_200 = 0xFFE2E8F0.toInt()
    const val SLATE_300 = 0xFFCBD5E1.toInt()
    const val SLATE_400 = 0xFF94A3B8.toInt()
    const val SLATE_500 = 0xFF64748B.toInt()
    const val SLATE_600 = 0xFF475569.toInt()
    const val SLATE_700 = 0xFF334155.toInt()
    const val SLATE_800 = 0xFF1E293B.toInt()
    const val SLATE_900 = 0xFF0F172A.toInt()
    const val BLUE_50 = 0xFFEFF6FF.toInt()
    const val BLUE_100 = 0xFFDBEAFE.toInt()
    const val BLUE_600 = 0xFF2563EB.toInt()
    const val BLUE_700 = 0xFF1D4ED8.toInt()
    const val EMERALD_50 = 0xFFECFDF5.toInt()
    const val EMERALD_400 = 0xFF34D399.toInt()
    const val EMERALD_500 = 0xFF10B981.toInt()
    const val EMERALD_700 = 0xFF047857.toInt()
    const val AMBER_50 = 0xFFFFFBEB.toInt()
    const val AMBER_400 = 0xFFFBBF24.toInt()
    const val AMBER_500 = 0xFFF59E0B.toInt()
    const val AMBER_700 = 0xFFB45309.toInt()
    const val RED_50 = 0xFFFEF2F2.toInt()
    const val RED_400 = 0xFFF87171.toInt()
    const val RED_600 = 0xFFDC2626.toInt()
    const val RED_700 = 0xFFB91C1C.toInt()
}

enum class Btn { PRIMARY, SECONDARY, DANGER, GHOST }
enum class Tone { GRAY, BLUE, GREEN, AMBER, RED }

/** Mažas „komponentų“ rinkinys Tailwind stiliumi, be jokių bibliotekų. */
class Ui(private val ctx: Context) {

    private val density = ctx.resources.displayMetrics.density
    fun dp(v: Int) = (v * density).toInt()
    fun dpf(v: Float) = v * density

    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val bold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)
    val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val mono: Typeface = Typeface.MONOSPACE

    fun shape(fill: Int, radius: Float = 8f, stroke: Int? = null, strokeW: Int = 1): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dpf(radius)
            if (stroke != null) setStroke(dp(strokeW), stroke)
        }

    fun ripple(fill: Int, radius: Float = 8f, stroke: Int? = null, rippleColor: Int = 0x1F0F172A): Drawable =
        RippleDrawable(ColorStateList.valueOf(rippleColor), shape(fill, radius, stroke), null)

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
           l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    // ------------------------------------------------------------ tekstas

    fun text(s: CharSequence, size: Float = 14f, color: Int = TW.SLATE_700, face: Typeface = regular): TextView =
        TextView(ctx).apply {
            text = s; textSize = size; setTextColor(color); typeface = face
            setLineSpacing(0f, 1.15f)
        }

    fun h1(s: String) = text(s, 20f, TW.SLATE_900, bold)
    fun h2(s: String) = text(s, 16f, TW.SLATE_900, medium)
    fun body(s: String) = text(s, 14f, TW.SLATE_600)
    fun muted(s: String) = text(s, 12f, TW.SLATE_500)
    fun monoText(s: String, size: Float = 12f, color: Int = TW.SLATE_700) = text(s, size, color, mono)

    /** text-xs font-semibold uppercase tracking-wide text-slate-500 */
    fun eyebrow(s: String) = text(s.uppercase(), 11f, TW.SLATE_500, medium).apply { letterSpacing = 0.08f }

    // ------------------------------------------------------------ mygtukai

    fun button(label: String, style: Btn = Btn.PRIMARY, onClick: () -> Unit): TextView =
        text(label, 15f, TW.WHITE, medium).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            isClickable = true; isFocusable = true
            when (style) {
                Btn.PRIMARY -> { background = ripple(TW.BLUE_600, 10f, rippleColor = 0x33FFFFFF); setTextColor(TW.WHITE) }
                Btn.DANGER -> { background = ripple(TW.WHITE, 10f, TW.RED_400); setTextColor(TW.RED_600) }
                Btn.SECONDARY -> { background = ripple(TW.WHITE, 10f, TW.SLATE_300); setTextColor(TW.SLATE_700) }
                Btn.GHOST -> { background = ripple(TW.BLUE_50, 10f); setTextColor(TW.BLUE_700) }
            }
            setOnClickListener { onClick() }
        }

    /** Mažas „chip“ mygtukas (pvz. terminalo greitosios komandos). */
    fun chip(label: String, active: Boolean = false, onClick: () -> Unit): TextView =
        text(label, 13f, if (active) TW.WHITE else TW.SLATE_700, medium).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = if (active) ripple(TW.BLUE_600, 999f, rippleColor = 0x33FFFFFF)
                         else ripple(TW.WHITE, 999f, TW.SLATE_200)
            isClickable = true
            setOnClickListener { onClick() }
        }

    // ------------------------------------------------------------ ženkliukai

    fun toneColors(t: Tone): Triple<Int, Int, Int> = when (t) {   // fonas, tekstas, rėmelis
        Tone.GRAY -> Triple(TW.SLATE_100, TW.SLATE_600, TW.SLATE_200)
        Tone.BLUE -> Triple(TW.BLUE_50, TW.BLUE_700, TW.BLUE_100)
        Tone.GREEN -> Triple(TW.EMERALD_50, TW.EMERALD_700, 0xFFA7F3D0.toInt())
        Tone.AMBER -> Triple(TW.AMBER_50, TW.AMBER_700, 0xFFFDE68A.toInt())
        Tone.RED -> Triple(TW.RED_50, TW.RED_700, 0xFFFECACA.toInt())
    }

    fun badge(s: String, tone: Tone): TextView {
        val (bg, fg, br) = toneColors(tone)
        return text(s, 12f, fg, medium).apply {
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = shape(bg, 999f, br)
        }
    }

    // ------------------------------------------------------------ išdėstymas

    fun vbox(): LinearLayout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    fun hbox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
    }

    /** bg-white rounded-xl border border-slate-200 shadow-sm p-4 */
    fun card(): LinearLayout = vbox().apply {
        background = shape(TW.WHITE, 14f, TW.SLATE_200)
        elevation = dpf(1.5f)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = lp(l = 12, t = 6, r = 12, b = 6)
    }

    fun divider(): View = View(ctx).apply {
        setBackgroundColor(TW.SLATE_100)
        layoutParams = lp(h = dp(1), t = 10, b = 10)
    }

    fun spacer(h: Int) = View(ctx).apply { layoutParams = lp(h = dp(h)) }

    /** Eilutė „pavadinimas ....... reikšmė“. */
    fun kv(key: String, value: String, valueColor: Int = TW.SLATE_900): LinearLayout = hbox().apply {
        setPadding(0, dp(6), 0, dp(6))
        addView(text(key, 14f, TW.SLATE_500), lp(w = 0, weight = 1f))
        addView(text(value, 14f, valueColor, medium).apply { gravity = Gravity.END }, lp(w = 0, weight = 1.3f))
    }
}
