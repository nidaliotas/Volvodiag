plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "lt.volvodiag"
    compileSdk = 34

    defaultConfig {
        applicationId = "lt.volvodiag"
        minSdk = 23
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
    }

    // Pastovus raktas – kad naujas APK įsidiegtų ant senojo (be išdiegimo)
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Jokių papildomų bibliotekų – tik Android SDK.
dependencies {
}
