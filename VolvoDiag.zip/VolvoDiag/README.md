# Volvo Diag (0.3)

Android programėlė Volvo diagnostikai per ELM327 Bluetooth adapterį.
Pirmasis etapas – standartinė OBD-II diagnostika ir terminalas Volvo bandymams.

## Ką moka
- **Adapteris** – suporuotų Bluetooth įrenginių sąrašas, prisijungimas, automatinis protokolo radimas (2003 m. XC70 – ISO 9141 K-line).
- **Klaidos** – variklio klaidų skaitymas (išsaugotos ir laukiančios), Check Engine būsena, VIN, klaidų trynimas.
- **Gyvi duomenys** – apsukos, temperatūros, MAF, kuro korekcijos, lambda, akumuliatoriaus įtampa (rodomi tik automobilio palaikomi parametrai).
- **Volvo moduliai** (bandomasis) – klaidų skaitymas iš Volvo modulių per greitąją (HS) ir lėtąją (MS) CAN magistralę, VIDA protokolu.
- **Bluetooth paieška** – naują adapterį galima rasti ir suporuoti tiesiai programėlėje; prisimena paskutinį adapterį.
- **Terminalas** – bet kokios ELM327 komandos ranka.
- **Žurnalas** – visa komunikacija su adapteriu; mygtukas „Kopijuoti“, kad galėtumėte atsiųsti Claude.

## Kaip susidiegti
1. Įsidiekite **Android Studio** (nemokama): https://developer.android.com/studio
2. Išarchyvuokite `VolvoDiag.zip`, Android Studio pasirinkite **File → Open** ir atidarykite `VolvoDiag` aplanką.
3. Palaukite, kol baigsis „Gradle sync“ (pirmą kartą atsisiunčia įrankius, gali užtrukti 5–10 min.).
4. Telefone įjunkite **kūrėjo režimą** (Nustatymai → Apie telefoną → 7 kartus spausti „Versijos numeris“) ir **USB derinimą**.
5. Prijunkite telefoną USB laidu ir Android Studio spauskite žalią ▶ **Run**.

Alternatyva: **Build → Build APK(s)**, o gautą `app-debug.apk` failą persikelkite į telefoną ir įdiekite.

## Naudojimas automobilyje
1. Adapterį į OBD lizdą (po vairu, kairėje), degimas II padėtyje.
2. Telefono Bluetooth nustatymuose suporuokite adapterį (PIN 1234 arba 0000).
3. Programėlėje „Adapteris“ → pasirinkite jį. Pirmas prisijungimas prie K-line gali užtrukti iki ~10 s.

## Volvo moduliai
Reikia ELM327 v1.4+ adapterio su HS/MS-CAN jungikliu. HS – variklis, pavarų dėžė, ABS; MS – CEM, prietaisų skydelis, klimatas, durys.
Protokolas paimtas iš bendruomenės atvirkštinės inžinerijos, todėl modulių adresai dalinai spėjami (pažymėti „(?)“).
Kitame etape: Volvo klaidų aprašymai ir trynimas.

## Atnaujinimas per GitHub
Įkelkite naują `VolvoDiag.zip` tuo pačiu pavadinimu – GitHub pats sukompiliuos naują versiją į Releases.
Nuo 0.2 versijos naujas APK įsidiegia ant senojo (pastovus pasirašymo raktas).
