# Volvo Diag (0.1)

Android programėlė Volvo diagnostikai per ELM327 Bluetooth adapterį.
Pirmasis etapas – standartinė OBD-II diagnostika ir terminalas Volvo bandymams.

## Ką moka
- **Adapteris** – suporuotų Bluetooth įrenginių sąrašas, prisijungimas, automatinis protokolo radimas (2003 m. XC70 – ISO 9141 K-line).
- **Klaidos** – variklio klaidų skaitymas (išsaugotos ir laukiančios), Check Engine būsena, VIN, klaidų trynimas.
- **Gyvi duomenys** – apsukos, temperatūros, MAF, kuro korekcijos, lambda, akumuliatoriaus įtampa (rodomi tik automobilio palaikomi parametrai).
- **Terminalas** – bet kokios ELM327 komandos ranka.
- **Žurnalas** – visa komunikacija su adapteriu; mygtukas „Kopijuoti“, kad galėtumėte atsiųsti Claude.

## Kaip susidiegti
1. Įsidiekite **Android Studio** (nemokama): https://developer.android.com/studio
2. Išarchyvuokite `VolvoDiag.zip`, Android Studio pasirinkite **File → Open** ir atidarykite `VolvoDiag` aplanką.
3. Palaukite, kol baigsis „Gradle sync“ (pirmą kartą atsisiunčia įrankius, gali užtrukti 5–10 min.).
4. Telefone įjunkite **kūrėjo režimą** (Nustatymai → Apie telefoną → 7 kartus spausti „Versijos numeris“) ir **USB derinimą**.
5. Prijunkite telefoną USB laidu ir Android Studio spauskite žalią ▶ **Run**.

Alternatyva: **Build → Build APK(s)**, o gautą `app-debug.apk` failą persikelkite į telefoną ir įdiekite.

## Naudojimas automobilyje
1. Adapterį į OBD lizdą (po vairu, kairėje), degimas II padėtyje.
2. Telefono Bluetooth nustatymuose suporuokite adapterį (PIN 1234 arba 0000).
3. Programėlėje „Adapteris“ → pasirinkite jį. Pirmas prisijungimas prie K-line gali užtrukti iki ~10 s.

## Kitas etapas – Volvo moduliai
CEM, ABS, SRS, TCM, klimato ir kitų modulių skaitymas per Volvo CAN (didelės ir mažos spartos).
Tam reikės adapterio su HS/MS-CAN jungikliu ir keleto bandymų per Terminalą – žurnalą atsiųsite Claude.
